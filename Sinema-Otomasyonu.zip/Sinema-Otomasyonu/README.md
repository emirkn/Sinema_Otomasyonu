# C-EREN Sineması
- Projenin Adı: C-EREN Sineması
- Projemizin amacını basitçe açıklamak gerekirse, bir sinema salonuna gittiğinizde hiç kimse ile etkileşime girmeden orada bulunan makineler aracılığıyla kendi biletinizi, yiyeceklerini, içeceklerini alıp filminizin tadını çıkartmanızı sağlamak.
- Ekip Üyeleri: Ceren KEPENEK 200702004 ve Eren YILMAZ 210702500
# Çalışma Mantığı
- Çalışma mantığı gayet basit. Size ilk başta ne yapmak istediğinizi soruyoruz, eğer yiyecek ve içecek alışverişi yapmak istiyorsanız o seçeneği veya direkt bilet almak istiyorsanız bilet alma seçeneğini seçeceksiniz.
Bilet alma kısmında ekranınızda boş koltuklar "B" harfi ile dolu koltuklar ise "D" harfi ile gösteriliyor. Siz de o boş koltuklardan belirttiğiniz adet kadar seçip alıyorsunuz.
Tüm işlemlerinizi gerçekleştirip sonunda çıkış yapmayı seçtiğinizde ise faturanız görüntüleniyor ve biletiniz size teslim ediliyor.
# Projede Kullanılan Teknik Kavramlar
- Değişkenler, Sabitler, Struct, Enum, If, For, While, Foreach, Diziler, Metotlar, Classlar, Property, Miras Alma, Kapsülleme ve son olarak hazır string metotlar.
